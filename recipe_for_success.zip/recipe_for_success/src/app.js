/**
 * Welcome to Pebble.js!
 *
 * This is where you write your app.
 */

var UI = require('ui');
var Vibe = require('ui/vibe');
var Light = require('ui/light');
var Vector2 = require('vector2');
var ajax = require('ajax');
var recipe;

Light.on();

ajax({ url: 'http://ec2-52-38-64-157.us-west-2.compute.amazonaws.com/angelhack/api.php/?get_recipe=1', type: 'json' },
  function(data) {
    console.log('Quote of the day is: ' + JSON.stringify(data));
    recipe = data; init();
  },
     function(error){
       console.log(JSON.stringify(error));
     }
);

var startRecipe = 0, done=0;
var a;
var stepNo = 1; //Keep track of step number
var maxSteps=34;
var startTime = Date.now();
 var wind = new UI.Window({
    backgroundColor: '#0091EA'
  });
  console.log("Haha!");
  console.log(Date.now() - startTime);

var timers = new Array();
var initTime = new Array();
var activeTimers = new Array();
var stamps = new Array();

var main = new UI.Card({
  title: '',
//   icon: 'images/menu_icon.png',
  fullscreen: true,
  subtitle: 'Start Recipe!',
  body: 'Press select.',
  subtitleColor: 'indigo', // Named colors
  bodyColor: '#9a0036', // Hex colors
  textAlign: 'center'
});

var end = new UI.Card({
  title: 'Congrats !',
//   icon: 'images/menu_icon.png',
  fullscreen: true,
  subtitle: 'Bon Appetite',
  body: 'Press select.',
  subtitleColor: 'indigo', // Named colors
  bodyColor: '#9a0036', // Hex colors
  textAlign: 'center'
});

var textfield = new UI.Text({
  position: new Vector2(40, 140),
  size: new Vector2(140, 60),
  font: 'gothic-24-bold',
  text: 'Dynamic\nWindow',
  textAlign: 'left'
});
textfield.text(Math.round((Date.now()-startTime)/1000)); 

var textTitle = new UI.Text({
  position: new Vector2(5, 0),
  size: new Vector2(140, 60),
  font: 'gothic-18-bold',
  text: '',//recipe.RecipeName.slice(0, 6)'',// + '| Step ' +stepNo.toString(),
  textAlign: 'left'
});


var topLine = new UI.Line({
  position: new Vector2(0, 35),
  position2: new Vector2(140, 35),
  strokeColor: 'white',
  strokeWidth: 2
});
var image = new UI.Image({
  position: new Vector2(20, 155),
  size: new Vector2(1, 1),
  image: 'images/smlmukl.png',
  backgroundColor: 'clear',
  compositing: 'set',
});


var textStep = new UI.Text({
  position: new Vector2(0, 0),
  size: new Vector2(140, 60),
  font: 'gothic-24-bold',
  text: 'Step ' +stepNo.toString(),
  textAlign: 'right'
});


var textPipe = new UI.Line({
  position: new Vector2(70, 0),
  position2: new Vector2(70, 35),
  strokeColor: 'white',
  strokeWidth: 2
});

//var textfieldPos = textfield.position().addSelf(new Vector2(0, 0)).subSelf(textfield.size()); 

var textInstruction = new UI.Text({
  position: new Vector2(0, 55),
  size: new Vector2(140, 60),
  font: 'gothic-24-bold',
  text:'',
  textAlign: 'center'
});
wind.add(textInstruction);
function fakeInit(){
  startRecipe = 0;
  stepNo = 1;
  main.title(recipe.RecipeName); 
  startTime = Date.now();
  for(var i=0; i<recipe.Instructions.length; i++){
    if(recipe.Instructions[i].Time)timers[i] = recipe.Instructions[i].Time;
    else timers[i] = 0;
    initTime[i] = timers[i];
    activeTimers[i] = -2;
  }
}
function init(){
  startRecipe = 0;
  stepNo = 1;
  startTime = Date.now();
  wind = new UI.Window({backgroundColor:'#0091EA'});
  timers = new Array();
  initTime = new Array();
  activeTimers = new Array();
  for(var i=0; i<recipe.Instructions.length; i++){
    if(recipe.Instructions[i].Time)timers[i] = recipe.Instructions[i].Time;
    else timers[i] = 0;
    initTime[i] = timers[i];
    activeTimers[i] = -2;
  }
  main.title(recipe.RecipeName);
  textTitle.text(recipe.RecipeName.slice(0, 6));
  textInstruction.text( recipe.Instructions[stepNo-1].Instruction);
  maxSteps = recipe.Instructions.length;
  
  wind.add(textTitle);
  wind.add(image);
  wind.add(topLine);
  wind.add(textStep);
  wind.add(textPipe);
  wind.add(textfield);
  windUpdate();
  main.show();
  
  wind.on('click', 'up', function(e) {
 if(stepNo > 1)stepNo--;
});

  
  main.on('click', 'select', function(e) {
    console.log("CLICKED SELECT ON MAIN!");
    if(startRecipe==0)startRecipe = 1; //To start the recipe from initial screen
    a = setInterval(function(){
      windUpdate(); console.log(stepNo);
    }, 1000);
    wind.show();
  });

  wind.on('click', 'select', function(e){
    if(activeTimers[stepNo-1]==0 || activeTimers[stepNo-1]==-2){ //If paused or never started, set it in motion!
      activeTimers[stepNo-1] = 1;
    }
    else if(activeTimers[stepNo-1]==1){
      activeTimers[stepNo-1] = 0; //If in motion, stop, update timers to remaining time.
      timers[stepNo-1] = (timers[stepNo-1]*60*1000-(Date.now()-stamps[stepNo-1]))/60000;
    }
    stamps[stepNo-1] = Date.now(); //Timestamp of last change.
  });
  
  var flag = 0;
  
  wind.on('click', 'down', function(e) {
  console.log(stepNo,maxSteps);
    if(flag == 1)
      {
        end.show();
        flag = 0;
      }
    if(stepNo < maxSteps)stepNo++;
    else if(stepNo == maxSteps)flag = 1;
  });
  
  wind.on('click', 'back', function(e){
    clearInterval(a); 
    console.log("Trying to go back")
    ajax({ url: 'http://ec2-52-38-64-157.us-west-2.compute.amazonaws.com/angelhack/api.php/?get_recipe=1', type: 'json' },
  function(data) {
    console.log('Quote of the day is: ' + JSON.stringify(data));
    recipe = data; done=1; fakeInit(); main.show();
  },
     function(error){
       console.log(JSON.stringify(error));
     }
);
    main.show();
  });
  
}


/*Main Card, Window, Textfields defined here*/





/*Main Card, Window, Textfields defined stop*/

function windUpdate(){
  textInstruction.text(recipe.Instructions[stepNo-1].Instruction);
  textStep.text('Step ' +stepNo.toString());
  if(activeTimers[stepNo-1]==0 || activeTimers[stepNo-1]==-2){ //Pause
    var est = timers[stepNo-1]*60*1000;
    var date = new Date(est);
    var s = date.getSeconds();
    var strS = s.toString();
    if(s<10)strS='0'+strS;
    textfield.text(Math.floor(est/60000).toString() +":" + strS);
  }
  else if(activeTimers[stepNo-1] == -1){ //Finished
    textfield.text("00:00");
  }

  else if(activeTimers[stepNo-1]==1){
    var est = timers[stepNo-1]*60*1000 - (Date.now()-stamps[stepNo-1]);
    var date = new Date(est);
    var s = date.getSeconds();
    var strS = s.toString();
    if(s<10)strS='0'+strS;
    textfield.text(Math.floor(est/60000).toString() +":" + strS);
  }
  for (var i in timers){
    if((timers[i]*60*1000 - (Date.now()-stamps[i]))<-10 && activeTimers[i]!=-1){
      activeTimers[i] = -1; //And make Background Green
      timers[i] = 0; stamps[i] = Date.now();
      Vibe.vibrate('short');Vibe.vibrate('short');Vibe.vibrate('short');
      
    }
  }
  if(recipe.Instructions[stepNo-1].Action == 'Boil')
  {
    console.log('kart');
    var icon = new UI.Image({
    position: new Vector2(130, 155),
    size: new Vector2(1, 1),
    image: 'images/boil.png',
    backgroundColor: 'clear',
    compositing: 'set',
    });
    wind.add(icon);
  }

  wind.add(textInstruction); 
  wind.add(textStep);
  textTitle.text(recipe.RecipeName.slice(0, 6));

  if(timers[stepNo-1]==0)image.compositing('clear'), textfield.text('');
  else image.compositing('set');
  wind.add(image);
  if(activeTimers[stepNo-1]==-1)wind.backgroundColor('#2E7D32'); //Green
  if(activeTimers[stepNo-1]==0)wind.backgroundColor('#BF360C'); //Red
  if(activeTimers[stepNo-1]==1)wind.backgroundColor('#8D6E63'); //Brown
  if(activeTimers[stepNo-1]==-2)wind.backgroundColor('#0091EA'); //Blue
  wind.show();
}

if(done==1){done=0; console.log("LOL!"); init();}
